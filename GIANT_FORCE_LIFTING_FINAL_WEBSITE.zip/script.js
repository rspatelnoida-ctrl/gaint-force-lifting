document.getElementById("year").textContent = new Date().getFullYear();
document.querySelector(".menu").addEventListener("click",()=> {
  const nav=document.querySelector(".header nav");
  nav.style.display = nav.style.display==="flex" ? "" : "flex";
  nav.style.position="absolute"; nav.style.top="72px"; nav.style.left="0"; nav.style.right="0";
  nav.style.padding="18px"; nav.style.background="#090909"; nav.style.flexDirection="column"; nav.style.alignItems="center";
});
document.getElementById("quoteForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  document.getElementById("formMsg").textContent="Thank you! Your enquiry form is ready. Connect your email/WhatsApp number in script.js or your hosting form service to receive submissions.";
});