GIANT FORCE & LIFTING WEBSITE
==============================

Files:
- index.html  : website structure/content
- style.css   : responsive black/gold industrial design
- script.js   : mobile menu, year and enquiry confirmation

BEFORE GOING LIVE:
1. Replace "YOUR PHONE NUMBER", "YOUR WHATSAPP NUMBER", "YOUR EMAIL" and "YOUR BUSINESS ADDRESS" in index.html.
2. Replace the WhatsApp href="https://wa.me/" with your WhatsApp number in international format.
3. Add your real product photos/logo if available.
4. For real enquiry delivery, connect the form to your preferred email/form service or backend.
5. Upload index.html, style.css and script.js to your hosting public_html folder.

The product descriptions are general marketing copy; verify your actual specifications, capacities and applicable standards before publishing.
